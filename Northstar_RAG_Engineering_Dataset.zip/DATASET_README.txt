NORTHSTAR SYSTEMS — RAG SYSTEMS ENGINEERING TRAINING DATASET
Fictional training documents; not real company policies.

Use the supplied source_manifest.json for trusted source/version/status/access metadata.
The actual files include one PDF, two HTML documents (one with a table), and four TXT documents.
The 2025 finance document is superseded; do not serve it in current-policy answers.
The Security Admin Runbook is available only to role it_admin, not employee.
The evaluation_questions.json contains training questions with ground-truth source IDs.
The questions with empty expected_sources test restricted/out-of-scope behavior; retrieval alone cannot establish whether such questions should be answered.

IMPORTANT: In production, roles and document access controls must come from trusted authenticated systems. A student selecting a role in a notebook is only a classroom simulation.
